Content:

* vendor.py
  - vendorization script
  - copied from https://github.com/openhwgroup/cv32e40p/blob/master/util/vendor.py, commit 69e839e
