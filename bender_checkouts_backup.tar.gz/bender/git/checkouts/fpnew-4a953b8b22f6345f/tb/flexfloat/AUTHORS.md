Giuseppe Tagliavini, Alma Mater Studiorum Università di Bologna, giuseppe.tagliavini@unibo.it
