iDMA Midends
============

Morty files:

.. only:: html

  `ND Backend <idma_nd_midend_synth/index.html>`_

.. image:: ../fig/graph/idma_nd_midend_synth.png
  :width: 600
