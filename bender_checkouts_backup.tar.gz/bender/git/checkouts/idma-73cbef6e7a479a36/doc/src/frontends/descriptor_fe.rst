Linux Frontend
=====================

Frontend for Ariane (CVA6) ready for Linux use.

.. only:: html

- `descriptor-based frontend <../regs/idma_desc64.html>`_

Morty docs:

.. only:: html

- `Morty docs <../idma_desc64_synth/index.html>`_

.. image:: ../../fig/graph/idma_desc64_synth.png
  :width: 600
